// Inera Edit Flow — loads the ONNX Runtime WebAssembly binary from two parts (each under GitHub's 25 MB
// web-upload limit), checks its size, and keeps it in Cache Storage so later visits start instantly.
const PARTS = ['ort-wasm-part1.bin', 'ort-wasm-part2.bin'];
const TOTAL = 26781914; // bytes of ort-wasm-simd-threaded.asyncify.wasm (onnxruntime-web 1.30)
const CACHE = 'inera-runtime-v1';
let binP = null;

async function fetchBytes(url) {
  const r = await fetch(url, { credentials: 'same-origin' });
  if (!r.ok) throw new Error(`AI runtime file missing (${url.split('/').pop()}, HTTP ${r.status}). Upload all files of the app.`);
  return new Uint8Array(await r.arrayBuffer());
}
async function load(base) {
  const key = new URL('ort-wasm-runtime-' + TOTAL + '.wasm', base).href;
  let cache = null;
  try { cache = await caches.open(CACHE); } catch (e) { /* Cache Storage unavailable */ }
  if (cache) {
    try { const hit = await cache.match(key); if (hit) { const b = new Uint8Array(await hit.arrayBuffer()); if (b.byteLength === TOTAL) return b; } } catch (e) { /* re-download */ }
  }
  const parts = await Promise.all(PARTS.map((p) => fetchBytes(new URL(p, base).href)));
  const n = parts.reduce((a, p) => a + p.byteLength, 0);
  if (n !== TOTAL) throw new Error(`AI runtime is incomplete (${n} of ${TOTAL} bytes). Re-upload ort-wasm-part1.bin and ort-wasm-part2.bin.`);
  const bin = new Uint8Array(n); let o = 0;
  for (const p of parts) { bin.set(p, o); o += p.byteLength; }
  if (cache) { try { await cache.put(key, new Response(bin.slice(), { headers: { 'content-type': 'application/wasm' } })); } catch (e) { /* quota */ } }
  return bin;
}
// Call once in a worker before creating any InferenceSession.
export async function setupOrt(ort, base) {
  if (!binP) { binP = load(base); binP.catch(() => { binP = null; }); }
  const bin = await binP;
  ort.env.wasm.wasmPaths = base; // the small JS glue file still loads from the site
  ort.env.wasm.wasmBinary = bin;
}
